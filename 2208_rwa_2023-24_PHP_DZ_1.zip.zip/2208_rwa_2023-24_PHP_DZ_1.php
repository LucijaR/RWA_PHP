<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
 <?php
 /* 1.	Korištenjem for petlje ispišite niz brojeve od 1 do 20 i njihove kvadrate. Svaki par ispisati u novi red! */
 print("Zadatak 1:</br>");
 
 for ($i=1; $i<=20; $i++)
 {
     print($i." ");
	 print($i * $i.'</br>');
 }
 
 /* 2.	Izračunati sumu prvih 100 prirodnih brojeva korištenjem for petlje*/ 
 print("</br>Zadatak 2:</br>");
 $suma=0;
 for ($i=1; $i<=100; $i++)
 {
     $suma=$suma+$i;
 }
 print($suma.'</br>');
 
 /* 3. Izračunati sumu prvih 100 prirodnih brojeva korištenjem while petlje*/
 print("</br>Zadatak 3:</br>");
 $suma=0;
 $i=0;
 while ($i<=100)
 {
     $suma=$suma+$i; 
	 $i++;
 }
 print($suma.'</br>');
 
 /* 4.	Napisati php skriptu/kod koja/i ispisuje sve parne brojeve od 1 do 100 , svaki broj u novom retku */
 print("</br>Zadatak 4:</br>");
 $i=1;
 while ($i<=100)
 {
     if($i % 2==0)
	 {
	  print($i.'</br>');
	  }
	$i++;
 }
 /* 4.	Ispisati sve troznamenkaste parne brojeve */
 print("</br>Zadatak 5:</br>");
 $i=100;
 while ($i<=999)
 {
     if($i % 2==0)
	 {
	  print($i.'</br>');
	  }
	$i++;
 }
 
 /*6. Ispisati sve dvoznamenkaste brojevi djeljive s 3 i 5 ili s oba!*/
 print("</br>Zadatak 6:</br>");
 $i=10;
 while ($i<100)
 {
     if(($i % 3==0) || ($i % 5==0))
	 {
	  print($i.'</br>');
	  }
	$i++;
 }
 
 /*7.	Zadana je varijabla $grad koja sadržava polje s članovima godina => broj stanovnika. Izračunajte: 
a.	a) Prosječan broj stanovnika kroz sve godine? 
b.	Koje godine je bilo najviše stanovnika? 
c.	Koliko godina se provodilo mjerenje? 
Primjer varijable 
$grad = array(1995 => 24000, 1997 => 25510, 1998 => 29154, 2000 =>32124, 2002 => 33114);*/
 print("</br>Zadatak 7:</br>");
 $grad = array(1995 => 24000, 1997 => 25510, 1998 => 29154, 2000 =>32124, 2002 => 33114);
 
 $ukupanBrojStanovnika = array_sum($grad);
$prosjecanBrojStanovnika = $ukupanBrojStanovnika / count($grad);
print("Prosjek:$prosjecanBrojStanovnika</br>");

$maxStanovnika = max($grad);
$godineMaxStanovnika = array_keys($grad, $maxStanovnika);
print("Godina s najviše stanovnika:".implode(', ',$godineMaxStanovnika).'</br>');

$brojGodina = count($grad);
print("Godine mjerenja: $brojGodina</br>");

/*8.	Napišite funkciju koja će ispitati da li je broj prost. Prosti brojevi su djeljivi isključivo sa samim sobom ili s 1. Zatim, ispišite sve proste brojeve manje od 100!*/
print("</br>Zadatak 8:</br>");
function provjera($x)
{
    $brojac=0;
    for ($i=2; $i<$x; $i++) 
	{
        if ($x % $i ==0) 
		{
            $brojac++;
        }
    }
    return $brojac;
}

print("Prosti brojevi manji od 100:</br>");
for ($i=2; $i<100; $i++) 
{
    if (provjera($i) == 0) 
	{
        print($i.'</br>');
    }
}

/*9.	Napišite PHP program koji će sve članove polja $brojevi zbrojiti pomoću foreach petlje:
$brojevi = array( 1, 22, 3, 4, 5, 55, 12, 49,94, 23, 7);
/*/
print("</br>Zadatak 9:</br>");
$brojevi = array(1, 22, 3, 4, 5, 55, 12, 49, 94, 23, 7);
$zbroj=0;

foreach ($brojevi as $broj) 
{
    $zbroj += $broj;
}
print("Zbroj je: ".$zbroj.'</br>');

/*10.	Dodijelite varijablama $a i $b proizvoljne cjelobrojne vrijednosti – širinu i dužinu zamišljenog pravokutnika. 
Izračunajte površinu pravokutnika i vrijednost zapišite u varijablu $pov_pravokutnik. 
Zatim spišite u browseru: "Površina pravokutnika širine ____ i dužine ___ iznosi ____" (popunite s vrijednostima iz varijabli) */
 print("</br>Zadatak 10:</br>");
$a = 18;
$b = 7; 
$pov_pravokutnik=$a * $b;

print("Površina pravokutnika širine $a i dužine $b iznosi $pov_pravokutnik");
 
 ?>
 
</body>
</html>